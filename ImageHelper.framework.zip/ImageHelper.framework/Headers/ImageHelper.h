//
//  ImageHelper.h
//  ImageHelper
//
//  Created by Marc Attinasi on 11/8/17.
//  Copyright © 2017 ServiceNow. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ImageHelper.
FOUNDATION_EXPORT double ImageHelperVersionNumber;

//! Project version string for ImageHelper.
FOUNDATION_EXPORT const unsigned char ImageHelperVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ImageHelper/PublicHeader.h>


